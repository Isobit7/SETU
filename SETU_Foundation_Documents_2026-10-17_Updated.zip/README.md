# SETU Foundation Documents — Updated Design Edition

This archive preserves the original SETU foundation documents and adds the user-requested translator-workspace design direction and button-by-button control guide.

## Added files

- `button.md` — purpose and behavior for every recommended button/control, disabled/error states, status indicators, and a phase-aware release checklist.
- `translator_workspace_design.md` — detailed camera framing, movie-style subtitle placement, real landmark overlay, layout, state handling, accessibility, privacy, responsiveness, and verification-first build order.
- `assets/SETU_Translator_Workspace_Mockup.png` — visual workspace concept; suitable for viewing/sharing.
- `assets/SETU_Translator_Workspace_Mockup.svg` — vector version of the concept board.
- `assets/SETU_Camera_Frame_Illustration.png` — cropped illustrative camera frame used by the concept board.

## Core design decision

The live camera preview is the main focus. Frame the signer from the head through the torso, with both hands, elbows, and signing space visible. Show detected hand landmarks over the camera; add body/pose landmarks when supported by the detector. Place translated text in a high-contrast, movie-style subtitle band at the bottom of the preview. If that band would hide tracked hands, reposition it or place it immediately below the video. Keep controls below the preview and Copy/Speak/Clear as secondary actions.

## Important phase boundary

The workspace is a **future P5 web-interface design target**, not a claim that the existing application already has a web UI, landmark overlay, speech output, history, or a validated translation. The original plan remains MVP-first: validate real licensed ISL samples and the five-sign local recognition flow before building the larger web interface. The mockup contains illustrative pixels/text only; runtime tracking/predictions must come from the real detector and model.

## Existing documents preserved

`PRD.md`, `architecture.md`, `rules.md`, `phase.md`, `design.md`, and `memory.md` remain in the archive. The PRD, phase plan, design guidance, and project memory have small additions to reflect the requested future UI while preserving the current P3/P4 priorities.
